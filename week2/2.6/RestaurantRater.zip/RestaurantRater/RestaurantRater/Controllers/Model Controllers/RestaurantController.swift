//
//  RestaurantController.swift
//  RestaurantRater
//
//  Created by Eric Lanza on 7/14/18.
//  Copyright © 2018 ETLanza. All rights reserved.
//

import Foundation
